package com.example.TodoListProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoListProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
